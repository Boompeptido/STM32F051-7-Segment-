/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;
DMA_HandleTypeDef hdma_adc;

/* USER CODE BEGIN PV */
unsigned short usStage_Display = 0;


//varieble for time
unsigned short usActivetime = 0;
unsigned short usmSec = 0;
unsigned short usSec = 0;
unsigned short usMin = 0;
unsigned short usHour = 0;
unsigned long ulCount = 0;

char number_array[32] = {0x3F,0x06,0x5B,0x4F,   // 0 , 1 ,2 , 3    //3
		                 0x66,0x6D,0x7D,0x07,   // 4 , 5 ,6 , 7    //7
						 0x7F,0x6F,0x77,0x7C,   // 8 , 9 , A , b   //11
						 0x39,0x5E,0x79,0x71,   // C , d ,E , F    //15
						 0x00,0x38,0x5C,0x3E,   // empty,L,o,U     //19
                         0x76,0x10,0x73,0x70,   // H , i,P,t       //23
                         0x5e,0x50,0x40,0x76,   // d,r,-,h         //27
                         0x36,0x54,0x6D,0x6e};  // ll,n,S           //31


uint8_t i,b = 0;
uint8_t digit[6];
uint16_t buffer[2];
int f = 0;
int dp_on = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC_Init(void);
/* USER CODE BEGIN PFP */
void Display_int_number(unsigned short number);
void Clear_Display(void);
void Display_Character(char a,char b ,char c ,char d,char e,char f);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  HAL_ADC_Start_DMA(&hadc, (uint32_t*)buffer, 2);
	 // HAL_Delay(1000);


			  ulCount++;
			  HAL_Delay(500);
			  Display_int_number(ulCount);

			  if(ulCount >= 50)
			  {
				  Clear_Display();
			  }
			  if(ulCount >= 55)
			  {
				  Display_Character('a','b','c','L','o','e');
			  }
			  if(ulCount >= 75)
			  {
				  Display_Character('a','b','c','d','e','f');
			  }

		/*	  if(ulCount>9999)
			  {
				 // usCount = 0;
				//digit[0] = bufer[0]%1000;           // X00 000   digit5
				  digit[2] = 3;                       //   X 000   digit3

				  digit[3] = 4;                       //     X00   digit2
				  digit[4] = 5;                        //      X0   digit1
				  digit[5] = 6;

			  }
			  if(ulCount>29999)
			  {
				  ulCount =0;
				  digit[0] = 10;           // X00 000   digit5
				  digit[1] = 11;           //  X0 000   digit4
				  digit[2] = 13;           //   X 000   digit3

				  digit[3] = 14;           //     X00   digit2
				  digit[4] = 15;           //      X0   digit1
				  digit[5] = 17;

			  }
              */

  }






    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSI14;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = ENABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_41CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, A_Pin|B_Pin|C_Pin|D_Pin
                          |E_Pin|F_Pin|G_Pin|DP_Pin
                          |K4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, K2_Pin|K3_Pin|K6_Pin|K7_Pin
                          |K8_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : A_Pin B_Pin C_Pin D_Pin
                           E_Pin F_Pin G_Pin DP_Pin
                           K4_Pin */
  GPIO_InitStruct.Pin = A_Pin|B_Pin|C_Pin|D_Pin
                          |E_Pin|F_Pin|G_Pin|DP_Pin
                          |K4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : K2_Pin K3_Pin K6_Pin K7_Pin
                           K8_Pin */
  GPIO_InitStruct.Pin = K2_Pin|K3_Pin|K6_Pin|K7_Pin
                          |K8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : SW_ENTER_Pin SW_Pin */
  GPIO_InitStruct.Pin = SW_ENTER_Pin|SW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void Display_int_number(unsigned short number)    //Function for show Number in 7segment
{
	  digit[0] =  number/100000;           				       // X00 000   digit5
	  digit[1] = (number%100000)/10000;          	           //  X0 000   digit4
	  digit[2] = ((number%100000)%10000)/1000;                 //   X 000   digit3
	  digit[3] = (((number%100000)%10000)%1000)/100;           //     X00   digit2
	  digit[4] = ((((number%100000)%10000)%1000)%100)/10;      //      X0   digit1
	  digit[5] = (((((number%100000)%10000)%1000)%100)%10)/1;  //
}

void Clear_Display(void)  //Function for show empty in 7segment
{
	 digit[0] =  16;           				//empty
	 digit[1] =  16;           				//empty
	 digit[2] =  16;           				//empty
	 digit[3] =  16;           				//empty
	 digit[4] =  16;           				//empty
	 digit[5] =  16;           				//empty

}

void Display_Character(char a,char b ,char c ,char d,char e,char f) //Function for show Charactor in 7segment
{

        // a //
		if(a == 'a')
		{
			digit[0] =  10;
		}
		else if(a == 'b')
		{
			digit[0] =  11;
		}
		else if(a == 'c')
		{
			digit[0] =  12;
		}
		else if(a == 'd')
		{
			digit[0] =  13;
		}
		else if(a == 'e')
		{
			digit[0] =  14;
		}
		else if(a == 'f')
		{
			digit[0] =  15;
		}
		else if (a == 'L')
		{
			digit[0] = 17;
		}
		else if (a == 'o')
		{
			digit[0] = 18;
		}
		else if (a == 'U')
		{
			digit[0] = 19;
		}
		else if (a == 'H')
		{
			digit[0] = 20;
		}
		else if (a == 'i')
		{
			digit[0] = 21;
		}
		else if (a == 'P')
		{
			digit[0] = 22;
		}
		else if (a == 't')
		{
			digit[0] = 23;
		}
		else if (a == 'r')
		{
			digit[0] = 25;
		}
		else if (a == '-')
		{
			digit[0] = 26;
		}
		else if (a == 'l')
		{
			digit[0] = 28;
		}
		else if (a == 'n')
		{
			digit[0] = 29;
		}
		else if (a == 'S')
		{
			digit[0] = 30;
		}
		else if (a =='*')
		{
			digit[0] = 16;
		}


        // b //
		if(b == 'a')
		{
			digit[1] =  10;
		}
		else if(b == 'b')
		{
			digit[1] =  11;
		}
		else if(b == 'c')
		{
			digit[1] =  12;
		}
		else if(b == 'd')
		{
			digit[1] =  13;
		}
		else if(b == 'e')
		{
			digit[1] =  14;
		}
		else if(b == 'f')
		{
			digit[1] =  15;
		}
		else if (b == 'L')
		{
			digit[1] = 17;
		}
		else if (b == 'o')
		{
			digit[1] = 18;
		}
		else if ( b == 'U')
		{
			digit[1] = 19;
		}
		else if (b == 'H')
		{
			digit[1] = 20;
		}
		else if (b == 'i')
		{
			digit[1] = 21;
		}
		else if (b == 'P')
		{
			digit[1] = 22;
		}
		else if (b == 't')
		{
			digit[1] = 23;
		}
		else if (b == 'r')
		{
			digit[1] = 25;
		}
		else if (b == '-')
		{
			digit[1] = 26;
		}
		else if (b == 'l')
		{
			digit[1] = 28;
		}
		else if (b == 'n')
		{
			digit[1] = 29;
		}
		else if (b == 'S')
		{
			digit[1] = 30;
		}
		else if (b =='*')
		{
			digit[1] = 16;
		}


		// c //
		if(c == 'a')
		{
			digit[2] =  10;
		}
		else if(c == 'b')
		{
			digit[2] =  11;
		}
		else if(c == 'c')
		{
			digit[2] =  12;
		}
		else if(c == 'd')
		{
			digit[2] =  13;
		}
		else if(c == 'e')
		{
			digit[2] =  14;
		}
		else if(c == 'f')
		{
			digit[2] =  15;
		}
		else if (c == 'L')
		{
			digit[2] = 17;
		}
		else if (c == 'o')
		{
			digit[2] = 18;
		}
		else if ( c == 'U')
		{
			digit[2] = 19;
		}
		else if (c == 'H')
		{
			digit[2] = 20;
		}
		else if (c == 'i')
		{
			digit[2] = 21;
		}
		else if (c == 'P')
		{
			digit[2] = 22;
		}
		else if (c == 't')
		{
			digit[2] = 23;
		}
		else if (c == 'r')
		{
			digit[2] = 25;
		}
		else if (c == '-')
		{
			digit[2] = 26;
		}
		else if (c == 'l')
		{
			digit[2] = 28;
		}
		else if (c == 'n')
		{
			digit[2] = 29;
		}
		else if (c == 'S')
		{
			digit[2] = 30;
		}
		else if (c =='*')
		{
			digit[2] = 16;
		}


		// d //
		if(d == 'a')
		{
			digit[3] =  10;
		}
		else if(d == 'b')
		{
			digit[3] =  11;
		}
		else if(d == 'c')
		{
			digit[3] =  12;
		}
		else if(d == 'd')
		{
			digit[3] =  13;
		}
		else if(d == 'e')
		{
			digit[3] =  14;
		}
		else if(d == 'f')
		{
			digit[3] =  15;
		}
		else if (d == 'L')
		{
			digit[3] = 17;
		}
		else if (d == 'o')
		{
			digit[3] = 18;
		}
		else if ( d == 'U')
		{
			digit[3] = 19;
		}
		else if (d == 'H')
		{
			digit[3] = 20;
		}
		else if (d == 'i')
		{
			digit[3] = 21;
		}
		else if (d == 'P')
		{
			digit[3] = 22;
		}
		else if (d == 't')
		{
			digit[3] = 23;
		}
		else if (d == 'r')
		{
			digit[3] = 25;
		}
		else if (d == '-')
		{
			digit[3] = 26;
		}
		else if (d == 'l')
		{
			digit[3] = 28;
		}
		else if (d == 'n')
		{
			digit[3] = 29;
		}
		else if (d == 'S')
		{
			digit[3] = 30;
		}
		else if (d =='*')
		{
			digit[3] = 16;
		}


		//e //
		if(e == 'a')
		{
			digit[4] =  10;
		}
		else if(e == 'b')
		{
			digit[4] =  11;
		}
		else if(e == 'c')
		{
			digit[4] =  12;
		}
		else if(e == 'd')
		{
			digit[4] =  13;
		}
		else if(e == 'e')
		{
			digit[4] =  14;
		}
		else if(e == 'f')
		{
			digit[4] =  15;
		}
		else if (e == 'L')
		{
			digit[4] = 17;
		}
		else if (e == 'o')
		{
			digit[4] = 18;
		}
		else if ( e == 'U')
		{
			digit[4] = 19;
		}
		else if (e == 'H')
		{
			digit[4] = 20;
		}
		else if (e == 'i')
		{
			digit[4] = 21;
		}
		else if (e == 'P')
		{
			digit[4] = 22;
		}
		else if (e == 't')
		{
			digit[4] = 23;
		}
		else if (e == 'r')
		{
			digit[4] = 25;
		}
		else if (e == '-')
		{
			digit[4] = 26;
		}
		else if (e == 'l')
		{
			digit[4] = 28;
		}
		else if (e == 'n')
		{
			digit[4] = 29;
		}
		else if (e == 'S')
		{
			digit[4] = 30;
		}
		else if (e =='*')
		{
			digit[4] = 16;
		}


		//f//
		if(f == 'a')
		{
			digit[5] =  10;
		}
		else if(f == 'b')
		{
			digit[5] =  11;
		}
		else if(f == 'c')
		{
			digit[5] =  12;
		}
		else if(f == 'd')
		{
			digit[5] =  13;
		}
		else if(f == 'e')
		{
			digit[5] =  14;
		}
		else if(f == 'f')
		{
			digit[5] =  15;
		}
		else if (f == 'L')
		{
			digit[5] = 17;
		}
		else if (f == 'o')
		{
			digit[5] = 18;
		}
		else if ( f == 'U')
		{
			digit[5] = 19;
		}
		else if (f == 'H')
		{
			digit[5] = 20;
		}
		else if (f == 'i')
		{
			digit[5] = 21;
		}
		else if (f == 'P')
		{
			digit[5] = 22;
		}
		else if (f == 't')
		{
			digit[5] = 23;
		}
		else if (f == 'r')
		{
			digit[5] = 25;
		}
		else if (f == '-')
		{
			digit[5] = 26;
		}
		else if (f == 'l')
		{
			digit[5] = 28;
		}
		else if (f == 'n')
		{
			digit[5] = 29;
		}
		else if (f == 'S')
		{
			digit[5] = 30;
		}
		else if (f =='*')
		{
			digit[5] = 16;
		}


}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
